module.exports = {
    PORT : process.env.PORT,
    DB_HOST: process.env.DB_HOST,
    JWT_SECRET_KEY : process.env.JWT_SECRET_KEY
}
