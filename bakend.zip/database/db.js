const  {DB_HOST} = require('../utility/config');

module.exports = {
    url:DB_HOST
}

